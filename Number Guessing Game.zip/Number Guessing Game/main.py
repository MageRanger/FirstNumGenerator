from type_guess import Type_Select

class Main():

    def __init_(self):
        self.self = self
    
    def PlayGame():
        Game = True

        while (Game == True):
            print("Do you want to guess a number? Type Yes or No\n")
            statement = ""

            if (statement == "Yes"):
                type = Type_Select.Select_Type()
            elif (statement == "No"):
                print("Thank you for playing")
                break
            else:
                Game = True
        
            print("Guess the number!\n")
            user_guess = input(float)
            if user_guess == type:
                print("You Win!\n")
            elif user_guess != type:
                print("You Loose!\n")

Main.PlayGame()