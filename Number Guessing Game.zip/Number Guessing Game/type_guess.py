from number_generator import NumberGenerator

class Type_Select:
    
    def __init_(self):
        self.self = self

    def Select_Type():
        Type = input("What would you like to guess, a integer or float? Type 'Integer' for integer, and 'Float' for float\n")

        while (i == False):
            if Type == "Integer":
                Type_Integer = NumberGenerator.Random_Integer()
                i = True
                return Type_Integer
            
            elif Type == "Float":
                Type_Float = NumberGenerator.Random_Float()
                i = True
                return Type_Float
            
            else:
                i = False



