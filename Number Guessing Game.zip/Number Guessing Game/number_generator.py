import random

class NumberGenerator():
    def __init__(self, number):
        self.number = number
    
    def Random_Integer():
        x = input(int("What is the starting position?\n"))
        y = input(int("What is the end position?\n"))
        z = input(int("What is the step count?\n"))
        result = random.randrange(x, y, z)
        return result
    
    def Random_Float():
        x = input(int("What is the starting position?\n"))
        y = input(int("What is the end position?\n"))
        result = random.uniform(x, y)
        return result
